#!/bin/bash

echo "4"
ls -lR | awk '$5 > 8192000 { print $9 " --- " $5 }' 
