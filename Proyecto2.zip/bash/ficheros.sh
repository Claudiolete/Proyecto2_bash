#!/bin/bash

find .  $HOME -user  `whoami` | sort -n




