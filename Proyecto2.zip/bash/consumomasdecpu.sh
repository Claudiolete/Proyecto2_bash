#!/bin/bash
echo "2"
ls -d1 $HOME */

echo "3"
ps aux --width 30 --sort -rss | head -n 4
