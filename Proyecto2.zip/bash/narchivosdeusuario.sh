#!/bin/bash

echo "El usuario tiene "

find . $HOME -user `whoami` | wc -l 

echo "ficheros"
