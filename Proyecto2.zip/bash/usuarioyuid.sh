#!/bin/bash

echo "Los usuarios reales son : \n"
cat /etc/passwd | sort | awk -F':' '$3 >= 1000 {printf"Usuario : " $1" | " " UID: " $3 " \n"}' 





