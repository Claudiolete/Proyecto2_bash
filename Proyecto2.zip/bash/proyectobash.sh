#!/bin/bash

#comentario, los siguientes comandos permiten saber la cpu y la memoria
echo "La memoria libre es :"

free -k |awk '{print $3","}'|sed -e 's/,//'|grep -v free

echo "estado de la cpu: "

ps -e -o pcpu,cputime,args --sort pcpu | sed '/^ 0.0 /d'

#comentario, los siguientes comandos permiten saber espacio libre en el disco


echo "El espacio libre es : `df | awk '{print $4}'`" |grep -v 1K

echo "El espacio usado es : `df | awk '{print $3}'`" |grep -v de

#comentario, los siguientes comandos permiten saber hora y fecha


DIA=`date +"%d"`
MES=`date +"%B"`
HORA=`date +"%H:%M"`

echo "Hoy es $DIA de $MES y la hora actual es $HORA!"

#comentario, los siguientes comandos permiten saber la cantidad de numeros de archivos y ademas de eso la memoria utilizada

echo "La cantidad de archivos que hay en el Home es :"

find . $HOME -type f | wc -l

echo "La cantidad de Mbytes utilizados por el Home son :"

$HOME du -s -m

##comentario, los siguientes comandos permiten saber nombre del host

echo "El nombre de la computadora es `hostname` " 

##comentario, los siguientes comandos permiten saber nombre del usuario que se esta utilizando

echo "El usuario $USER está conectado desde `uptime -s`"
