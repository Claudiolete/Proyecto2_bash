#!/bin/bash

find . $HOME -type d  | sort -n
