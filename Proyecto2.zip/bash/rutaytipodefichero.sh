#!/bin/bash
ls $HOME -d1 


echo "Ingrese:"
read ruta
find ${HOME} -name $ruta -type f
