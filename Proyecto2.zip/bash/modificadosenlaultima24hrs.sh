find $HOME -mtime 0

muestra los archivos modificados del home en las ultimas 24 hrs
