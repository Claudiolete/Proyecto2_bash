
public class main {
    public  static void main(String[] args) {

        Control control = new Control();



    }
}
