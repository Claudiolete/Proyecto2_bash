import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class Control {

    Scanner scanner;


    public Control() {

        scanner = new Scanner(System.in);
        estadoSistema();
        menu();
    }

    public void estadoSistema() {

        try {
            //Process p = Runtime.getRuntime().exec("ls -llt");
            Process p = Runtime.getRuntime().exec("./bash/proyectobash.sh");
            BufferedReader in = new BufferedReader(new InputStreamReader(p.getInputStream()));

            String line = null;

            while ((line = in.readLine()) != null) {
                System.out.println(line);
            }
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }

    public void menu() {

        while (true) {
            int opcion, opcion2,opcion3;

            System.out.println("Que desea hacer? ");
            System.out.println("[1] Visualizar Usuarios ");
            System.out.println("[2] Ficheros y procesos ");
            System.out.println("[3] Actividades de usuarios ");

            opcion = scanner.nextInt();

            while (opcion > 3 || opcion < 1) {

                System.out.println("Opcion invalida");
                opcion = scanner.nextInt();
            }
            switch (opcion) {
                case 1:

                    visualizarUsuarios();
                    System.out.println("[0]Para filtrar usuarios por su letra inicial ");

                    opcion2 = scanner.nextInt();

                    while (opcion2 != 0) {
                        System.out.println("Ingrese una opcion valida ");
                        opcion2 = scanner.nextInt();

                    }
                    switch (opcion2) {
                        case 0:
                            String ll;
                            System.out.println("ingrese la letra para filtrar");
                            ll = scanner.nextLine();
                            try {
                                //Process p = Runtime.getRuntime().exec("ls -llt");
                                Process p = Runtime.getRuntime().exec("./bash/ordenusuarios.sh " + ll);
                                BufferedReader in = new BufferedReader(new InputStreamReader(p.getInputStream()));

                                String line = null;

                                while ((line = in.readLine()) != null) {
                                    System.out.println(line);
                                }
                            } catch (IOException e) {
                                System.out.println(e.getMessage());
                            }
                            break;
                    }
                    break;

                case 2:

                    visualizarFicherosyProcesos();
                    System.out.println("[0] Para ver los ficheros del usurio ordenados ");
                    System.out.println("[1] Para ver los directorios del usuario ordenados ");
                    System.out.println("[2] Para ver la cantidad archivos con tamaño mas grande que 1024 Kbyte ");
                    System.out.println("[3] Para buscar un archivo y mostrar su ruta ");
                    opcion3 = scanner.nextInt();

                    while (opcion3 < 0 || opcion3 >4) {
                        System.out.println("Ingrese una opcion valida ");
                        opcion2 = scanner.nextInt();

                    }
                    if(opcion3 == 0){
                        try {
                            //Process p = Runtime.getRuntime().exec("ls -llt");
                            Process p = Runtime.getRuntime().exec("./bash/narchivosdeusuario.sh ");
                            BufferedReader in = new BufferedReader(new InputStreamReader(p.getInputStream()));

                            String line = null;

                            while ((line = in.readLine()) != null) {
                                System.out.println(line);
                            }
                        } catch (IOException e) {
                            System.out.println(e.getMessage());
                        }
                        break;
                    }
                    if(opcion3 == 1 ){
                        try {
                            //Process p = Runtime.getRuntime().exec("ls -llt");
                            Process p = Runtime.getRuntime().exec("./bash/ndirectoriosdelusuario.sh");
                            BufferedReader in = new BufferedReader(new InputStreamReader(p.getInputStream()));

                            String line = null;

                            while ((line = in.readLine()) != null) {
                                System.out.println(line);
                            }
                        } catch (IOException e) {
                            System.out.println(e.getMessage());
                        }
                        break;
                    }
                    if(opcion3 == 2) {
                        try {
                            //Process p = Runtime.getRuntime().exec("ls -llt");
                            Process p = Runtime.getRuntime().exec("./bash/ordendearchivos.sh");
                            BufferedReader in = new BufferedReader(new InputStreamReader(p.getInputStream()));

                            String line = null;

                            while ((line = in.readLine()) != null) {
                                System.out.println(line);
                            }
                        } catch (IOException e) {
                            System.out.println(e.getMessage());
                        }
                        break;
                    }
                    if(opcion3 == 3){
                        try {
                            //Process p = Runtime.getRuntime().exec("ls -llt");
                            Process p = Runtime.getRuntime().exec("./bash/rutaytipodefichero.sh ");
                            BufferedReader in = new BufferedReader(new InputStreamReader(p.getInputStream()));

                            String line = null;

                            while ((line = in.readLine()) != null) {
                                System.out.println(line);
                            }
                        } catch (IOException e) {
                            System.out.println(e.getMessage());
                        }
                        break;
                    }

                case 3:
                    actividadesDeUsuario();
            }

        }
    }


    public void visualizarUsuarios() {

        Scanner scanner = new Scanner(System.in);

        try{
            //Process p = Runtime.getRuntime().exec("ls -llt");
            Process p = Runtime.getRuntime().exec("./bash/usuarioyuid.sh ");
            BufferedReader in = new BufferedReader(new InputStreamReader(p.getInputStream()));

            String line = null;

            while ((line = in.readLine()) != null){
                System.out.println(line);
            }
        }
        catch(IOException e){
            System.out.println(e.getMessage());
        }
    }

    public void visualizarFicherosyProcesos()
    {
        try{
            //Process p = Runtime.getRuntime().exec("ls -llt");
            Process p = Runtime.getRuntime().exec("./bash/narchivosdeusuario.sh");
            BufferedReader in = new BufferedReader(new InputStreamReader(p.getInputStream()));

            String line = null;

            while ((line = in.readLine()) != null){
                System.out.println(line);
            }
        }
        catch(IOException e){
            System.out.println(e.getMessage());
        }
    }

    public void actividadesDeUsuario()
    {
        System.out.println("Aun no habilitado ):");
    }
}



